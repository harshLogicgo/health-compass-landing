export const navItems = [
  {
    title: "Home",
    path: "/",
  },
  {
    title: "Services",
    path: "#service",
  },
];

