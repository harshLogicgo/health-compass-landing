export const ROUTES = {
  LOGIN: "https://health-compass-60829.web.app/#/login",
  SIGNUP: "https://health-compass-60829.web.app/#/signup",
};
